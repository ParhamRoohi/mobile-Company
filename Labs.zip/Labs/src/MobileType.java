public enum MobileType {
    Android,
    Ios, 
    Windows,
}
